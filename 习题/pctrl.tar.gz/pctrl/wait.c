#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>

int main()
{
    pid_t pid = fork();
    if (pid == 0) {
        sleep(10);
        exit(99);
    }
    int status;
    printf("wait \n");
    //int ret = wait(&status);
    //waitpid(pid, status, options)
    wait(&status);
    if (WIFEXITED(status)) {
        printf("retval:%d\n", WEXITSTATUS(status));
    }
    int ret;
    while((ret = waitpid(pid, &status, WNOHANG)) == 0) {
        printf("子进程还没有退出，先吃完饭~~\n");
        sleep(1);
    }
    if ((status & 0x7f) == 0) {
        printf("ret:%d; pid:%d; status:%d\n", ret, pid, (status>>8) & 0xff);
    }else {
        printf("程序是异常退出的\n");
    }

    //能走下来的是父进程，因为子进程在上边运行exit后就退出了
    while(1) {
        printf("-------\n");
        sleep(1);
    }
    return 0;
}
