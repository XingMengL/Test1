#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

void function()
{
    printf("leihoua~");
    sleep(3);
    //exit(0);//在任意位置调用exit都会退出进程
    _exit(0);//在任意位置调用_exit都会退出进程
    return;
}
int main()
{
    int *a = NULL;
    *a = 100;
    function();
    //printf("nihao\n");
    return 0;
}
