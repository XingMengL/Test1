#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main()
{
    printf("nihaoa~~~~~~~\n");
    char *argv[] = {"./env", "-a", "-l", NULL};
    char *env[] = {"MYVAL=1000", "PATH=./", NULL};
    //execl("/usr/bin/ls", "ls", "-a", "-l", NULL);
    execve("./env", argv, env);
    printf("leihoua~~~~~~\n");
    return 0;
}
