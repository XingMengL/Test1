#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>

int main()
{
    while(1) {
        printf("[zhangwenchao@localhost]# ");
        fflush(stdout);//刷新标准输出缓冲区

        char buf[1024] = {0};
        fgets(buf, 1023, stdin);//从标准输入读取一行数据
        buf[strlen(buf) - 1] = '\0';//将最后的换行字符替换成为字符串结尾标志
        printf("buf:[%s]\n", buf);

        char *ptr = buf;
        char *argv[32] = {NULL};
        int argc = 0;
        //  [   ls  -a   -l]
        while(*ptr != '\0') {
            if (*ptr != ' ') {
                //这就是单独每个字符串的起始位置
                argv[argc] = ptr; //argv[0]=l的位置
                argc++;
                while(*ptr != ' ' && *ptr != '\0') ptr++;
                *ptr = '\0';
            }
            ptr++;
        }
        argv[argc] = NULL;//参数以NULL作为结尾

        pid_t pid = fork();
        if (pid == 0) {
            //复制了父进程，因此也有自己的argc/argv
            //子进程运行新的程序，使用程序替换，
            //当前我们运行的程序都是PATH环境变量指定的路径下的程序。因此p
            execvp(argv[0], argv);
            printf("%s command not found\n", argv[0]);
            exit(-1);
        }

        wait(NULL);//等待子进程退出，避免子进程成为僵尸进程

    }
    return 0;
}
